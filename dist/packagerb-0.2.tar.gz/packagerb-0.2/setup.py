from setuptools import setup
setup(name="packagerb",
version="0.2",
description="This is code with rb package",
long_description="This is a very very long description",
author="Rakshya",
packages=['packagerb'],
install_requires=[])
