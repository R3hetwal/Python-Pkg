class Good:
    def __init__():
        print("Constructor formed")

    def goodfun(self, number):
        print("This is a function")
        return number

